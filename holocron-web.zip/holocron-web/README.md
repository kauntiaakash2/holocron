# Jedi Holocron — standalone Three.js web implementation

**Scope:** Reference-informed closed Jedi Holocron approximation. This is not a direct model of the original production prop or a validated screen-accurate replica. No official textures, meshes, or asset files are included.

## Preview

Use a local web server. Opening `index.html` directly from `file://` may block ES module imports.

```bash
cd holocron-web
python3 -m http.server 8080
# open http://localhost:8080
```

The model loads Three.js from `https://esm.sh/three@0.169.0`, so a network connection and WebGL-enabled browser are required. For production, pin and self-host a bundled dependency through your application build pipeline.

## Embedding anywhere (recommended)

Upload the `holocron-web` directory to a publicly reachable path on your site and embed:

```html
<iframe
  title="Interactive Jedi Holocron"
  src="/holocron-web/index.html?embed=1"
  loading="lazy"
  style="width:100%;height:540px;border:0;background:transparent"
></iframe>
```

For Next.js or React, put these files in `public/holocron-web/` and use the same `iframe`. This keeps the dependency isolated and avoids React lifecycle collisions. Give the parent a defined height. You can add `&rotate=false` to initially disable spin.

Send simple actions from a same-page parent app:

```js
const iframe = document.querySelector('iframe[title="Interactive Jedi Holocron"]');
iframe.contentWindow.postMessage({ type: 'holocron:activate' }, location.origin);
iframe.contentWindow.postMessage({ type: 'holocron:rotation', enabled: false }, location.origin);
```

If the iframe is hosted on another origin, use that exact origin instead of `location.origin`. The demo accepts messages only from its parent window; if using a different-origin embed, harden the listener to an explicit allowed-origin allowlist before production use.

## Direct Three.js API

`holocron.js` exports `Holocron` with `activate()`, `setAutoRotate(bool)`, `resize()`, and `dispose()`. This module imports Three.js from a CDN. If integrating into a bundler-based project, replace its import with `import * as THREE from 'three'` and install the package in your app to avoid duplicate runtimes.

## Quality, limitations, and next steps

- Geometry is real procedural 3D: structural rails, panels, a raised diamond, concentric rings and corner elements.
- The six faces are symmetrical approximations pending a verified multi-angle reference survey.
- The model is not a GLB and does not include a native Blender `.blend` source; it is a portable runtime model built in JavaScript.
- The translucent core is alpha-blended rather than physically accurate refraction; physically correct transmission would require environment maps and validation.
- Rendering requires WebGL; a textual graceful error is supplied but not a separate static poster yet.
- Mobile performance and screen-reader behavior require real-device validation. Reduced-motion prevents spin, bob, and idle animation but keeps rendering available.
- If this will be shipped commercially, assess Star Wars trademark/IP usage and clarify fan-made status.
