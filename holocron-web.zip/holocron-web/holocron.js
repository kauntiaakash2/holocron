import * as THREE from 'https://esm.sh/three@0.169.0';

/** Standalone, reference-informed *approximation* of the Clone Wars closed Jedi Holocron.
 * This is purpose-built runtime geometry, not a scanned or canonically screen-accurate asset.
 */
export class Holocron {
  constructor(host, options = {}) {
    this.host = host;
    this.options = { autoRotate: true, interactive: true, ...options };
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
    this.camera.position.set(5.9, 4.35, 7.7);
    this.camera.lookAt(0, 0, 0);
    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.47;
    this.renderer.setClearColor(0x000000, 0);
    host.append(this.renderer.domElement);
    this.renderer.domElement.setAttribute('aria-label', 'Interactive three-dimensional Jedi Holocron');
    this.root = new THREE.Group();
    this.scene.add(this.root);
    this.clock = new THREE.Clock();
    this.pointer = new THREE.Vector2();
    this.velocity = 0;
    this.activation = 0;
    this.active = false;
    this.materials = this.makeMaterials();
    this.construct();
    this.lightScene();
    this.root.rotation.set(-0.23, 0.55, 0.15);
    this.bindHandlers();
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(host);
    this.resize();
    this.tick = this.tick.bind(this);
    this.frame = requestAnimationFrame(this.tick);
  }
  makeMaterials() {
    const metal = (c, roughness = 0.32) => new THREE.MeshStandardMaterial({color: c, metalness: .92, roughness, envMapIntensity: 1});
    return {
      gold: metal(0x967048),
      lightGold: metal(0xc09c65, .26),
      trim: metal(0x695033, .36),
      shade: metal(0x362b27, .46),
      core: new THREE.MeshPhysicalMaterial({color: 0x073b58, roughness: .21, metalness: .16, clearcoat: .95, clearcoatRoughness: .16, transparent: true, opacity: .94, side: THREE.DoubleSide}),
      crystal: new THREE.MeshPhysicalMaterial({color:0x0b6286, emissive:0x064e76, emissiveIntensity:.34, metalness:.08, roughness:.22, transparent:true, opacity:.79, side:THREE.DoubleSide, depthWrite:false}),
      glow: new THREE.MeshBasicMaterial({color:0x1bc9ed, transparent:true, opacity:.1, depthWrite:false, blending:THREE.AdditiveBlending}),
      darkBlue: new THREE.MeshStandardMaterial({color:0x072333, emissive:0x041d2b, emissiveIntensity:.22, roughness:.22, metalness:.12})
    };
  }
  mesh(geo, mat, parent, x=0,y=0,z=0) {
    const m = new THREE.Mesh(geo,mat);m.position.set(x,y,z);parent.add(m);return m;
  }
  bar(parent, a, b, radius, mat, radial=8) {
    const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b);
    const dir = new THREE.Vector3().subVectors(end,start);
    const m=this.mesh(new THREE.CylinderGeometry(radius,radius,dir.length(),radial),mat,parent);
    m.position.copy(start).add(end).multiplyScalar(.5);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());
    return m;
  }
  panel(parent, points, depth, mat, z) {
    const s=new THREE.Shape();s.moveTo(points[0][0],points[0][1]);
    points.slice(1).forEach(p=>s.lineTo(p[0],p[1]));s.closePath();
    const g=new THREE.ExtrudeGeometry(s,{depth, bevelEnabled:true,bevelSize:.014,bevelThickness:.012,bevelSegments:2,steps:1});
    return this.mesh(g,mat,parent,0,0,z);
  }
  polyRail(parent, coords, r, material, z) {
    for(let i=0;i<coords.length;i++) {
      const a=coords[i],b=coords[(i+1)%coords.length];this.bar(parent,[a[0],a[1],z],[b[0],b[1],z],r,material);
    }
  }
  construct() {
    const M=this.materials;
    this.mesh(new THREE.BoxGeometry(2.42,2.42,2.42),M.darkBlue,this.root);
    this.mesh(new THREE.BoxGeometry(2.33,2.33,2.33),M.core,this.root);
    this.inner=this.mesh(new THREE.IcosahedronGeometry(.76,1),M.glow,this.root);
    this.inner.scale.set(1,1,1);
    const frame = new THREE.BoxGeometry(2.54,.15,.18);
    const groups = [];
    for (let f=0;f<6;f++) {
      const g=new THREE.Group();this.root.add(g);groups.push(g);
      // Faces are modeled outward along local +Z; orient their complete assemblies.
      if(f===0)g.position.z=1.23;
      if(f===1){g.position.z=-1.23;g.rotation.y=Math.PI;}
      if(f===2){g.position.x=1.23;g.rotation.y=Math.PI/2;}
      if(f===3){g.position.x=-1.23;g.rotation.y=-Math.PI/2;}
      if(f===4){g.position.y=1.23;g.rotation.x=-Math.PI/2;}
      if(f===5){g.position.y=-1.23;g.rotation.x=Math.PI/2;}
      // Recessed blue field and inner border.
      this.mesh(new THREE.PlaneGeometry(2.22,2.22),M.crystal,g,0,0,.018);
      const outer=[[-1.15,-1.15],[1.15,-1.15],[1.15,1.15],[-1.15,1.15]];
      this.polyRail(g,outer,.077,M.gold,.18);
      const inner=[[-1.045,-1.045],[1.045,-1.045],[1.045,1.045],[-1.045,1.045]];
      this.polyRail(g,inner,.027,M.lightGold,.19);
      // Face corner structural triangles; solid inset fills are real extruded geometry.
      for(const sx of [-1,1])for(const sy of [-1,1]) {
        const p=[[sx*1.08,sy*1.08],[sx*.46,sy*1.08],[sx*1.08,sy*.46]];
        this.panel(g,p,.05,M.trim,.09);
        const q=[[sx*1.01,sy*1.01],[sx*.62,sy*1.01],[sx*1.01,sy*.62]];
        this.panel(g,q,.018,M.gold,.157);
        this.bar(g,[sx*.44,sy*1.065,.17],[sx*1.065,sy*.44,.17],.038,M.lightGold);
      }
      // Distinctive 45-degree square lattice around the central circular roundel.
      const diamond=[[0,1.005],[1.005,0],[0,-1.005],[-1.005,0]];
      this.polyRail(g,diamond,.075,M.gold,.232);
      const diamondInner=[[0,.88],[.88,0],[0,-.88],[-.88,0]];
      this.polyRail(g,diamondInner,.026,M.lightGold,.249);
      // Four divided blue triangular windows within the diamond.
      for(let i=0;i<4;i++) {
        const a=i*Math.PI/2;
        const v=[[.2,.2],[.72,.10],[.47,.47]];
        const pts=v.map(([x,y])=>[x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a)]);
        this.panel(g,pts,.012,M.core,.057);
      }
      // Central circular motif includes actual concentric raised rings.
      this.mesh(new THREE.CircleGeometry(.515,72),M.crystal,g,0,0,.169);
      this.mesh(new THREE.RingGeometry(.44,.50,80),M.shade,g,0,0,.202);
      this.mesh(new THREE.TorusGeometry(.535,.074,10,88),M.gold,g,0,0,.265);
      this.mesh(new THREE.TorusGeometry(.405,.023,8,88),M.lightGold,g,0,0,.276);
      this.mesh(new THREE.CircleGeometry(.355,72),M.darkBlue,g,0,0,.203);
      this.mesh(new THREE.CircleGeometry(.325,72),M.crystal,g,0,0,.211);
      this.mesh(new THREE.TorusGeometry(.255,.013,8,80),M.trim,g,0,0,.222);
      // Four restrained reinforcing details, without invented sci-fi runes.
      for(let i=0;i<4;i++) {
        const a=i*Math.PI/2;
        this.bar(g,[.59*Math.cos(a),.59*Math.sin(a),.271],[.78*Math.cos(a),.78*Math.sin(a),.27],.027,M.trim);
      }
      // Interior corner relief, behind primary lattice.
      for(const sx of [-1,1])for(const sy of [-1,1]) {
        this.bar(g,[sx*.91,sy*.88,.13],[sx*.82,sy*.92,.13],.02,M.lightGold);
      }
    }
    // Corner posts and edges establish coherent silhouette between adjacent faces.
    for(const axis of ['x','y','z'])for(const u of [-1,1])for(const v of [-1,1]) {
      const a=[0,0,0],b=[0,0,0];const rem=['x','y','z'].filter(s=>s!==axis);
      a['xyz'.indexOf(axis)]=-1.2;b['xyz'.indexOf(axis)]=1.2;
      a['xyz'.indexOf(rem[0])]=u*1.2;b['xyz'.indexOf(rem[0])]=u*1.2;
      a['xyz'.indexOf(rem[1])]=v*1.2;b['xyz'.indexOf(rem[1])]=v*1.2;
      this.bar(this.root,a,b,.085,M.gold,8);
    }
    for(const x of [-1.2,1.2])for(const y of [-1.2,1.2])for(const z of [-1.2,1.2]) {
      this.mesh(new THREE.OctahedronGeometry(.16,0),M.lightGold,this.root,x,y,z);
    }
  }
  lightScene() {
    this.scene.add(new THREE.AmbientLight(0x98b5d6,1.18));
    const key = new THREE.DirectionalLight(0xffddae,3.7);key.position.set(-4,7,8);this.scene.add(key);
    const fill = new THREE.DirectionalLight(0x42b8ff,2.2);fill.position.set(5,0,-5);this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0xffffff,1.15);rim.position.set(-1,-5,-3);this.scene.add(rim);
  }
  bindHandlers(){
    this.move=(e)=>{if(!this.options.interactive)return;const r=this.host.getBoundingClientRect();this.pointer.set(((e.clientX-r.left)/r.width-.5)*2,((e.clientY-r.top)/r.height-.5)*2);};
    this.leave=()=>this.pointer.set(0,0);
    this.renderer.domElement.addEventListener('pointermove',this.move);
    this.renderer.domElement.addEventListener('pointerleave',this.leave);
    this.visibility=()=>{this.hidden=document.hidden;};document.addEventListener('visibilitychange',this.visibility);
  }
  activate() {this.active=!this.active;return this.active;}
  setAutoRotate(value){this.options.autoRotate=Boolean(value);}
  resize(){const w=Math.max(this.host.clientWidth,1),h=Math.max(this.host.clientHeight,1);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.renderer.setSize(w,h,false);}
  tick(){
    this.frame=requestAnimationFrame(this.tick);
    const dt=Math.min(this.clock.getDelta(),.04);
    if(this.hidden)return;
    const t=this.clock.elapsedTime;
    const target=this.active?1:0;
    this.activation+= (target-this.activation)*Math.min(1,dt*2.7);
    if(!this.reducedMotion) {
      if(this.options.autoRotate)this.root.rotation.y+=dt*(.115*(1-this.activation));
      this.root.rotation.x+=((-0.19-this.pointer.y*.075)-this.root.rotation.x)*Math.min(1,dt*2.3);
      this.root.rotation.z+=((.10-this.pointer.x*.06)-this.root.rotation.z)*Math.min(1,dt*2.3);
      this.root.position.y=Math.sin(t*1.05)*.085;
    }
    this.materials.crystal.emissiveIntensity=.33+this.activation*.8+(!this.reducedMotion?Math.sin(t*1.6)*.035:0);
    this.materials.glow.opacity=.09+this.activation*.19;
    this.inner.rotation.y+=this.reducedMotion?0:dt*.09;
    this.renderer.render(this.scene,this.camera);
  }
  dispose(){cancelAnimationFrame(this.frame);this.resizeObserver.disconnect();this.renderer.domElement.removeEventListener('pointermove',this.move);this.renderer.domElement.removeEventListener('pointerleave',this.leave);document.removeEventListener('visibilitychange',this.visibility);this.root.traverse(o=>{if(o.geometry)o.geometry.dispose();});Object.values(this.materials).forEach(m=>m.dispose());this.renderer.dispose();this.renderer.domElement.remove();}
}
